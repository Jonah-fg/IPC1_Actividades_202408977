package actividad.pkg7.ipc1;

import Controlador.controladorCalculadora;
import Modelo.Usuario;
import Modelo.calculadoraModelo;
import Vista.Vistacalculadora;
import javax.swing.SwingUtilities;

public class Actividad7IPC1 {

    public static void main(String[] args) {
        Usuario u = new Usuario("Jonathan Eduardo Fuentes", "202408977");
        calculadoraModelo modelo = new calculadoraModelo(u);
        Vistacalculadora vista = new Vistacalculadora();
        controladorCalculadora controlador = new controladorCalculadora(modelo, vista);
        vista.setVisible(true);
    }
    
}
