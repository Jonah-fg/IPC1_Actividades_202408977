package Controlador;

import Modelo.calculadoraModelo;
import Vista.Vistacalculadora;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class controladorCalculadora {
    private calculadoraModelo modelo;
    private Vistacalculadora vista;

    public controladorCalculadora(calculadoraModelo modelo, Vistacalculadora vista) {
        this.modelo = modelo;
        this.vista = vista;
        
    
        this.vista.addSumarListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sumar();
            }
        }
       );
        
        this.vista.addRestarListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                restar();
            }
        }
       );
        
        this.vista.addMultiplicarListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                multiplicar();
            }
        }
        );
        
        this.vista.addDividirListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dividir();
            }
        }
        );
        
        this.vista.addLimpiarListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        }
        );
        
        this.vista.setUsuarioInfo(modelo.getUsuario().toString());
    }
    private void sumar() {
        try {
            double numero1 = Double.parseDouble(vista.getNumero1());
            double numero2 = Double.parseDouble(vista.getNumero2());
            double resultado = modelo.suma(numero1, numero2);
            vista.SetResultado(String.valueOf(resultado));
        } 
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Por favor un ingrese núeros válidos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void dividir() {
        try {
            double num1 = Double.parseDouble(vista.getNumero1());
            double num2 = Double.parseDouble(vista.getNumero2());
            double resultado = modelo.dividision(num1, num2);
            vista.SetResultado(String.valueOf(resultado));
        } 
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese números válidos", 
                "Error", JOptionPane.ERROR_MESSAGE);
        } 
        catch (ArithmeticException ex) {
            JOptionPane.showMessageDialog(vista, "No se puede dividir por cero", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
       
    private void limpiar() {
    vista.limpiarDatos();
    }
    
    private void multiplicar() {
        try{
            double numero1 = Double.parseDouble(vista.getNumero1());
            double numero2 = Double.parseDouble(vista.getNumero2());
            double resultado = modelo.multiplicacion(numero1, numero2);
            vista.SetResultado(String.valueOf(resultado));
        } 
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese números válidos", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
     private void restar(){
        try {
            double numero1 = Double.parseDouble(vista.getNumero1());
            double numero2 = Double.parseDouble(vista.getNumero2());
            double resultado = modelo.resta(numero1, numero2);
            vista.SetResultado(String.valueOf(resultado));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese números válidos", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
