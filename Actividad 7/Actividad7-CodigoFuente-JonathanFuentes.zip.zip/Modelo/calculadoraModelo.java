package Modelo;
public class calculadoraModelo {
    private Usuario usuario;

    public calculadoraModelo(Usuario usuario) {
        this.usuario = usuario;
    }
    
     public Usuario getUsuario() {
        return usuario;
    }
    
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;   
    }
    
    
    public double suma(double a, double b) {
        return a + b;
    }
    
    public double resta(double a, double b) {
        return a - b;
    }
    
    public double multiplicacion(double a, double b) {
        return a * b;
    }
    public double dividision(double a, double b){
        if(b==0){
            throw new ArithmeticException("No se puede dividir por cero");
        }
        return a/b;
    }
}
